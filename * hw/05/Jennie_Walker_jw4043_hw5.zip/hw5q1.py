
#asks user for number
n = int(input("Please enter a number.")) 
#prints the first n odd numbers 
for i in range(1, n*2+1, 2):
    print(i)
